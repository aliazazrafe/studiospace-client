
"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { toast } from "sonner";

const quickLinks = [
  { name: "Home", href: "/" },
  { name: "Explore Studios", href: "/studios" },
  { name: "How It Works", href: "/#how-it-works" },
  { name: "About Us", href: "/about" },
  { name: "Contact Us", href: "/contact" },
];

const hostLinks = [
  { name: "Add Your Studio", href: "/add-studio" },
  { name: "My Listings", href: "/my-listings" },
  { name: "My Bookings", href: "/my-bookings" },
];

const categories = [
  { name: "Photo Studios", value: "Photo Studios" },
  { name: "Sound Stages", value: "Sound Stages" },
  { name: "Podcast Rooms", value: "Podcast Rooms" },
  { name: "Music Suites", value: "Music Suites" },
  { name: "Art Workshops", value: "Art Workshops" },
];

const socialLinks = [
  {
    name: "Facebook",
    href: "https://www.facebook.com/",
    label: "f",
  },
  {
    name: "Instagram",
    href: "https://www.instagram.com/",
    label: "IG",
  },
  {
    name: "LinkedIn",
    href: "https://www.linkedin.com/",
    label: "in",
  },
];

export default function Footer() {
  const [email, setEmail] = useState("");

  const handleSubscribe = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const cleanEmail = email.trim();

    if (!cleanEmail) {
      toast.error("Please enter your email address.");
      return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(cleanEmail)) {
      toast.error("Please enter a valid email address.");
      return;
    }

    toast.info("Newsletter subscriptions will be available soon.");
  };

  return (
    <footer className="bg-gray-950 text-gray-300">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-5">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-xl font-bold text-white"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-500 text-white">
                ◈
              </span>

              <span>
                Studio<span className="text-orange-500">Space</span>
              </span>
            </Link>

            <p className="mt-4 max-w-sm text-sm leading-7 text-gray-400">
              Discover and book inspiring creative studios for photography,
              podcasts, music production, filming, and workshops. Your next
              great idea deserves the perfect space.
            </p>

            {/* Social Links */}
            <div className="mt-5 flex items-center gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.name}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-800 text-xs font-bold text-white transition hover:bg-orange-500"
                >
                  {social.label}
                </a>
              ))}

              {/* New X Logo */}
              <a
                href="https://x.com/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="X"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-800 text-white transition hover:bg-orange-500"
              >
                <svg
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  className="h-4 w-4 fill-current"
                >
                  <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.847h-7.406l-5.8-7.584-6.64 7.584H.47l8.6-9.83L0 1.153h7.594l5.243 6.932 6.064-6.932Zm-1.29 19.49h2.04L6.486 3.24H4.298l13.313 17.403Z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-5 text-sm font-bold text-white">
              Quick Links
            </h3>

            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-400 transition hover:text-orange-400"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Host Links */}
          <div>
            <h3 className="mb-5 text-sm font-bold text-white">
              For Hosts
            </h3>

            <ul className="space-y-3">
              {hostLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-400 transition hover:text-orange-400"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="mb-5 text-sm font-bold text-white">
              Popular Categories
            </h3>

            <ul className="space-y-3">
              {categories.map((category) => (
                <li key={category.name}>
                  <Link
                    href={`/studios?category=${encodeURIComponent(
                      category.value
                    )}`}
                    className="text-sm text-gray-400 transition hover:text-orange-400"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mt-12 grid gap-6 rounded-2xl border border-gray-800 bg-gray-900 p-6 md:grid-cols-2 md:items-center md:p-8">
          <div>
            <h3 className="text-lg font-bold text-white">
              Stay Inspired
            </h3>

            <p className="mt-2 text-sm leading-6 text-gray-400">
              Get updates about new studios, creative opportunities,
              and platform news.
            </p>
          </div>

          <form
            onSubmit={handleSubscribe}
            className="flex flex-col gap-3 sm:flex-row"
          >
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>

            <input
              id="newsletter-email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="Enter your email address"
              required
              className="min-w-0 flex-1 rounded-xl border border-gray-700 bg-gray-800 px-4 py-3 text-sm text-white outline-none transition placeholder:text-gray-500 focus:border-orange-500"
            />

            <button
              type="submit"
              className="rounded-xl bg-orange-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-orange-600"
            >
              Subscribe
            </button>
          </form>
        </div>

        {/* Footer Bottom */}
        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-gray-800 pt-6 text-center sm:flex-row sm:text-left">
          <p className="text-xs text-gray-500">
            © 2026 StudioSpace. All rights reserved.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-5 text-xs text-gray-500">
            <span>Built for creative communities</span>

            <Link
              href="/contact"
              className="transition hover:text-white"
            >
              Contact &amp; Support
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
