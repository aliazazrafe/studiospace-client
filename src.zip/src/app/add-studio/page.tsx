
"use client";

import {
  useState,
  useEffect,
  type ChangeEvent,
  type FormEvent,
} from "react";
import Link from "next/link";
import { toast } from "sonner";

const categories = [
  "Photo Studios",
  "Podcast Rooms",
  "Music Suites",
  "Art Workshops",
  "Sound Stages",
  "Other",
];

const availableAmenities = [
  "Wi-Fi",
  "Air Conditioning",
  "Parking",
  "Lighting Equipment",
  "Soundproof",
  "Restroom",
  "Photography Equipment",
  "Waiting Area",
];

type StudioFormData = {
  title: string;
  category: string;
  location: string;
  price: string;
  securityDeposit: string;
  capacity: string;
  description: string;
  imageUrl: string;
};

const initialForm: StudioFormData = {
  title: "",
  category: "",
  location: "",
  price: "",
  securityDeposit: "",
  capacity: "",
  description: "",
  imageUrl: "",
};

export default function AddStudioPage() {
  const [formData, setFormData] = useState(initialForm);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [previewError, setPreviewError] = useState(false);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Host information will come from authentication later.
  const hostName = "";
  const hostEmail = "";

  const inputClass =
    "w-full min-w-0 rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm text-gray-800 outline-none transition placeholder:text-gray-400 focus:border-orange-500 focus:ring-2 focus:ring-orange-100 disabled:cursor-not-allowed disabled:opacity-60";

  const labelClass =
    "mb-2 block text-sm font-semibold text-gray-800";

  useEffect(() => {
    if (!selectedFile) {
      setPreviewUrl(formData.imageUrl.trim());
      return;
    }

    const objectUrl = URL.createObjectURL(selectedFile);
    setPreviewUrl(objectUrl);

    return () => URL.revokeObjectURL(objectUrl);
  }, [selectedFile, formData.imageUrl]);

  const handleChange = (
    event: ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value } = event.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));

    setMessage("");
    setPreviewError(false);
  };

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities((previous) =>
      previous.includes(amenity)
        ? previous.filter((item) => item !== amenity)
        : [...previous, amenity]
    );
  };

  const handleFileChange = (
    event: ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];

    if (!file) {
      setSelectedFile(null);
      return;
    }

    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/webp",
    ];

    if (!allowedTypes.includes(file.type)) {
      toast.error("Please select a JPG, PNG or WebP image.");
      event.target.value = "";
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size must be less than 5 MB.");
      event.target.value = "";
      return;
    }

    setSelectedFile(file);
    setPreviewError(false);
    setMessage("");
    toast.success("Image selected for preview.");
  };

  const handleSubmit = async (
    event: FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();
    if (isLoading) return;

    setMessage("");

    if (
      !formData.title.trim() ||
      !formData.category ||
      !formData.location.trim() ||
      !formData.price ||
      !formData.capacity ||
      !formData.description.trim() ||
      !formData.securityDeposit
    ) {
      toast.error("Please fill in all required fields.");
      return;
    }

    const price = Number(formData.price);
    const deposit = Number(formData.securityDeposit);
    const capacity = Number(formData.capacity);

    if (!Number.isFinite(price) || price <= 0) {
      toast.error("Hourly price must be greater than zero.");
      return;
    }

    if (!Number.isFinite(deposit) || deposit < 0) {
      toast.error("Security deposit cannot be negative.");
      return;
    }

    if (!Number.isInteger(capacity) || capacity <= 0) {
      toast.error("Capacity must be a positive whole number.");
      return;
    }

    if (formData.description.trim().length < 20) {
      toast.error("Description must contain at least 20 characters.");
      return;
    }

    if (!selectedFile && !formData.imageUrl.trim()) {
      toast.error("Please select an image or provide an image URL.");
      return;
    }

    if (!selectedFile) {
      try {
        const url = new URL(formData.imageUrl.trim());

        if (!["http:", "https:"].includes(url.protocol)) {
          throw new Error("Invalid URL");
        }
      } catch {
        toast.error("Please provide a valid studio image URL.");
        return;
      }
    }

    setIsLoading(true);

    try {
      // Real image hosting and database saving will be added later.
      await new Promise<void>((resolve) =>
        setTimeout(resolve, 500)
      );

      const demoMessage =
        "Demo mode: Your studio has not been published. Image hosting, authentication and database integration are pending.";

      setMessage(demoMessage);
      toast.info("Studio listing is not connected to the backend yet.");
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen w-full overflow-x-hidden bg-gray-50 px-4 py-7 text-gray-900 sm:px-6 sm:py-10">
      <div className="mx-auto w-full max-w-4xl">
        <Link
          href="/studios"
          className="mb-5 inline-flex items-center gap-2 text-sm font-medium text-gray-600 transition hover:text-orange-500"
        >
          ← Back to Studios
        </Link>

        <div className="mb-8">
          <p className="mb-2 text-xs font-bold uppercase tracking-[2px] text-orange-500">
            Become a Host
          </p>

          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            List Your Creative Studio
          </h1>

          <p className="mt-3 max-w-2xl text-sm leading-7 text-gray-500">
            Share your creative space with photographers, artists,
            musicians and creators.
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          noValidate
          className="space-y-7 rounded-2xl border border-gray-200 bg-white p-4 shadow-sm sm:p-7"
        >
          {/* Basic Information */}
          <section>
            <h2 className="mb-5 text-lg font-bold">
              Basic Information
            </h2>

            <div className="grid gap-5 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label htmlFor="title" className={labelClass}>
                  Studio Name *
                </label>

                <input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="Professional Photography Studio"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />
              </div>

              <div>
                <label htmlFor="category" className={labelClass}>
                  Category *
                </label>

                <select
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  disabled={isLoading}
                  required
                  className={inputClass}
                >
                  <option value="">Select category</option>

                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="location" className={labelClass}>
                  Location *
                </label>

                <input
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="Dhanmondi, Dhaka"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />
              </div>
            </div>
          </section>

          <div className="h-px bg-gray-100" />

          {/* Pricing */}
          <section>
            <h2 className="mb-5 text-lg font-bold">
              Pricing & Capacity
            </h2>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label htmlFor="price" className={labelClass}>
                  Price Per Hour (৳) *
                </label>

                <input
                  id="price"
                  type="number"
                  name="price"
                  min="1"
                  step="0.01"
                  value={formData.price}
                  onChange={handleChange}
                  placeholder="1500"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />
              </div>

              <div>
                <label htmlFor="securityDeposit" className={labelClass}>
                  Security Deposit (৳) *
                </label>

                <input
                  id="securityDeposit"
                  type="number"
                  name="securityDeposit"
                  min="0"
                  step="0.01"
                  value={formData.securityDeposit}
                  onChange={handleChange}
                  placeholder="2000"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />
              </div>

              <div>
                <label htmlFor="capacity" className={labelClass}>
                  Maximum Capacity *
                </label>

                <input
                  id="capacity"
                  type="number"
                  name="capacity"
                  min="1"
                  step="1"
                  value={formData.capacity}
                  onChange={handleChange}
                  placeholder="10"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />
              </div>
            </div>
          </section>

          <div className="h-px bg-gray-100" />

          {/* Host Information */}
          <section>
            <h2 className="mb-2 text-lg font-bold">
              Host Information
            </h2>

            <p className="mb-5 text-sm text-gray-500">
              Host details will be filled automatically after login
              authentication is connected.
            </p>

            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label htmlFor="hostName" className={labelClass}>
                  Host Name
                </label>

                <input
                  id="hostName"
                  type="text"
                  value={hostName}
                  placeholder="Available after login"
                  readOnly
                  className={`${inputClass} cursor-not-allowed bg-gray-100`}
                />
              </div>

              <div>
                <label htmlFor="hostEmail" className={labelClass}>
                  Host Email
                </label>

                <input
                  id="hostEmail"
                  type="email"
                  value={hostEmail}
                  placeholder="Available after login"
                  readOnly
                  className={`${inputClass} cursor-not-allowed bg-gray-100`}
                />
              </div>
            </div>
          </section>

          <div className="h-px bg-gray-100" />

          {/* Description */}
          <section>
            <h2 className="mb-5 text-lg font-bold">
              Studio Description
            </h2>

            <label htmlFor="description" className={labelClass}>
              Tell Us About Your Studio *
            </label>

            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows={5}
              minLength={20}
              placeholder="Describe your studio, equipment, facilities and what makes it special..."
              disabled={isLoading}
              required
              className={`${inputClass} resize-y`}
            />

            <p className="mt-2 text-xs text-gray-400">
              Minimum 20 characters.
            </p>
          </section>

          <div className="h-px bg-gray-100" />

          {/* Amenities */}
          <section>
            <h2 className="mb-2 text-lg font-bold">
              Studio Amenities
            </h2>

            <p className="mb-5 text-sm text-gray-500">
              Select the facilities available at your studio.
            </p>

            <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3">
              {availableAmenities.map((amenity) => {
                const selected = selectedAmenities.includes(amenity);

                return (
                  <label
                    key={amenity}
                    className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 text-sm transition ${
                      selected
                        ? "border-orange-500 bg-orange-50 text-orange-700"
                        : "border-gray-200 text-gray-700 hover:border-orange-300"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selected}
                      onChange={() => toggleAmenity(amenity)}
                      disabled={isLoading}
                      className="h-4 w-4 accent-orange-500"
                    />
                    {amenity}
                  </label>
                );
              })}
            </div>
          </section>

          <div className="h-px bg-gray-100" />

          {/* Studio Image */}
          <section>
            <h2 className="mb-2 text-lg font-bold">
              Studio Image
            </h2>

            <p className="mb-5 text-sm text-gray-500">
              Choose an image from your device or provide a public URL.
            </p>

            <div className="space-y-4">
              <div>
                <label htmlFor="studioImage" className={labelClass}>
                  Upload Studio Image
                </label>

                <input
                  id="studioImage"
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleFileChange}
                  disabled={isLoading}
                  className="block w-full rounded-xl border border-dashed border-gray-300 bg-gray-50 p-4 text-sm text-gray-600 file:mr-4 file:rounded-lg file:border-0 file:bg-orange-100 file:px-4 file:py-2 file:font-semibold file:text-orange-600 hover:file:bg-orange-200"
                />

                <p className="mt-2 text-xs text-gray-400">
                  JPG, PNG or WebP. Maximum size: 5 MB.
                </p>
              </div>

              <div className="text-center text-xs font-semibold text-gray-400">
                OR
              </div>

              <div>
                <label htmlFor="imageUrl" className={labelClass}>
                  Studio Image URL
                </label>

                <input
                  id="imageUrl"
                  type="url"
                  name="imageUrl"
                  value={formData.imageUrl}
                  onChange={handleChange}
                  placeholder="https://example.com/studio.jpg"
                  disabled={isLoading || Boolean(selectedFile)}
                  className={inputClass}
                />
              </div>

              {selectedFile && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(null);
                    setPreviewError(false);
                    const fileInput = document.getElementById(
                      "studioImage"
                    ) as HTMLInputElement | null;
                    if (fileInput) fileInput.value = "";
                  }}
                  className="text-xs font-semibold text-red-500 hover:underline"
                >
                  Remove Selected Image
                </button>
              )}

              {previewUrl && !previewError && (
                <div className="overflow-hidden rounded-xl border border-gray-200">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={previewUrl}
                    alt="Studio preview"
                    onError={() => setPreviewError(true)}
                    className="h-48 w-full object-cover sm:h-64"
                  />
                </div>
              )}

              {previewError && (
                <p className="text-sm text-red-500">
                  Image preview could not be loaded.
                </p>
              )}

              <p className="text-xs leading-5 text-amber-700">
                Image selection currently provides a local preview only.
                Actual image hosting will be connected later.
              </p>
            </div>
          </section>

          {/* Demo Message */}
          {message && (
            <div
              role="status"
              className="rounded-xl border border-orange-200 bg-orange-50 p-4 text-sm leading-6 text-orange-800"
            >
              {message}
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-col-reverse gap-3 border-t border-gray-100 pt-6 sm:flex-row sm:justify-end">
            <Link
              href="/studios"
              className="rounded-xl border border-gray-300 px-6 py-3 text-center text-sm font-semibold text-gray-700 transition hover:bg-gray-50"
            >
              Cancel
            </Link>

            <button
              type="submit"
              disabled={isLoading}
              aria-busy={isLoading}
              className="flex items-center justify-center gap-3 rounded-xl bg-orange-500 px-7 py-3 text-sm font-bold text-white transition hover:bg-orange-600 disabled:opacity-60"
            >
              {isLoading ? "Validating..." : "Create Studio Listing →"}
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
