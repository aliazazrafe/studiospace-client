
"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { toast } from "sonner";

export default function RegisterPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [photoURL, setPhotoURL] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState("");

  const inputClass =
    "w-full rounded-lg border border-gray-300 bg-white px-4 py-3 text-sm text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 disabled:opacity-60";

  const labelClass = "mb-2 block text-sm font-semibold text-gray-800";

  const passwordChecks = [
    {
      label: "At least 6 characters",
      valid: password.length >= 6,
    },
    {
      label: "One uppercase letter (A-Z)",
      valid: /[A-Z]/.test(password),
    },
    {
      label: "One lowercase letter (a-z)",
      valid: /[a-z]/.test(password),
    },
  ];

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (isLoading) return;

    setMessage("");

    if (
      !name.trim() ||
      !email.trim() ||
      !photoURL.trim() ||
      !password ||
      !confirmPassword
    ) {
      toast.error("Please fill in all required fields.");
      setMessage("Please fill in all required fields.");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      toast.error("Please enter a valid email address.");
      return;
    }

    try {
      const url = new URL(photoURL.trim());

      if (!["http:", "https:"].includes(url.protocol)) {
        throw new Error("Invalid image URL");
      }
    } catch {
      toast.error("Please enter a valid photo URL.");
      return;
    }

    if (!passwordChecks.every((check) => check.valid)) {
      toast.error(
        "Password needs 6 characters, an uppercase and a lowercase letter."
      );
      return;
    }

    if (password !== confirmPassword) {
      toast.error("Passwords do not match.");
      return;
    }

    if (!agreeTerms) {
      toast.warning("Please agree to the Terms and Conditions.");
      return;
    }

    setIsLoading(true);

    try {
      await new Promise<void>((resolve) => {
        setTimeout(resolve, 500);
      });

      setMessage(
        "Registration is in demo mode. No account has been created yet."
      );

      toast.info("Backend authentication is not connected yet.");
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = () => {
    toast.info("Google Sign-in will be enabled with authentication.");
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-gray-50 px-3 py-6 text-gray-900 sm:px-5 sm:py-10">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-xl md:grid-cols-2">
        {/* Left Image */}
        <div className="relative hidden min-h-[850px] md:block">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=1200"
            alt="Creative workspace"
            className="absolute inset-0 h-full w-full object-cover"
          />

          <div className="absolute inset-0 bg-black/60" />

          <div className="relative z-10 flex h-full flex-col justify-between p-8 text-white lg:p-10">
            <Link
              href="/"
              className="text-2xl font-bold tracking-tight"
            >
              Studio<span className="text-orange-400">Space</span>
            </Link>

            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-orange-300">
                Join Our Community
              </p>

              <h1 className="text-3xl font-bold leading-tight lg:text-4xl">
                Your Creative
                <br />
                Journey Starts Here.
              </h1>

              <p className="mt-5 max-w-sm text-sm leading-7 text-gray-200">
                Join StudioSpace to discover amazing studios,
                connect with creative people, and turn your
                ideas into reality.
              </p>
            </div>

            <p className="text-xs text-gray-300">
              © 2026 StudioSpace. All rights reserved.
            </p>
          </div>
        </div>

        {/* Right Form */}
        <div className="flex items-center justify-center px-4 py-8 sm:px-8 md:px-8 lg:px-12">
          <div className="w-full max-w-md">
            <Link
              href="/"
              className="mb-5 inline-block text-2xl font-bold md:hidden"
            >
              Studio<span className="text-orange-500">Space</span>
            </Link>

            <div>
              <Link
                href="/"
                className="inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition hover:text-orange-500"
              >
                ← Back to Home
              </Link>
            </div>

            <div className="mb-6 mt-5">
              <p className="text-xs font-semibold uppercase tracking-widest text-orange-500">
                Get Started
              </p>

              <h2 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">
                Create Your Account
              </h2>

              <p className="mt-2 text-sm leading-6 text-gray-500">
                Join StudioSpace and discover your creative space.
              </p>
            </div>

            <form
              onSubmit={handleSubmit}
              noValidate
              className="space-y-4"
            >
              {/* Name */}
              <div>
                <label htmlFor="name" className={labelClass}>
                  Full Name
                </label>

                <input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  placeholder="Enter your full name"
                  autoComplete="name"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className={labelClass}>
                  Email Address
                </label>

                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@example.com"
                  autoComplete="email"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />
              </div>

              {/* Photo URL */}
              <div>
                <label htmlFor="photoURL" className={labelClass}>
                  Profile Photo URL
                </label>

                <input
                  id="photoURL"
                  type="url"
                  value={photoURL}
                  onChange={(event) => setPhotoURL(event.target.value)}
                  placeholder="https://example.com/photo.jpg"
                  disabled={isLoading}
                  required
                  className={inputClass}
                />

                <p className="mt-1 text-xs text-gray-400">
                  Paste a public URL of your profile photo.
                </p>
              </div>

              {/* Password */}
              <div>
                <label htmlFor="password" className={labelClass}>
                  Password
                </label>

                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(event) =>
                      setPassword(event.target.value)
                    }
                    placeholder="Create a strong password"
                    autoComplete="new-password"
                    disabled={isLoading}
                    required
                    className={`${inputClass} pr-16`}
                  />

                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    disabled={isLoading}
                    aria-label={
                      showPassword ? "Hide password" : "Show password"
                    }
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-500 hover:text-orange-500"
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>

                {/* Password Rules */}
                <div className="mt-2 space-y-1">
                  {passwordChecks.map((check) => (
                    <p
                      key={check.label}
                      className={`flex items-center gap-2 text-xs ${
                        check.valid
                          ? "text-green-600"
                          : "text-gray-400"
                      }`}
                    >
                      <span aria-hidden="true">
                        {check.valid ? "✓" : "○"}
                      </span>
                      {check.label}
                    </p>
                  ))}
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label
                  htmlFor="confirmPassword"
                  className={labelClass}
                >
                  Confirm Password
                </label>

                <div className="relative">
                  <input
                    id="confirmPassword"
                    type={
                      showConfirmPassword ? "text" : "password"
                    }
                    value={confirmPassword}
                    onChange={(event) =>
                      setConfirmPassword(event.target.value)
                    }
                    placeholder="Confirm your password"
                    autoComplete="new-password"
                    disabled={isLoading}
                    required
                    className={`${inputClass} pr-16`}
                  />

                  <button
                    type="button"
                    onClick={() =>
                      setShowConfirmPassword((value) => !value)
                    }
                    disabled={isLoading}
                    aria-label={
                      showConfirmPassword
                        ? "Hide confirm password"
                        : "Show confirm password"
                    }
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold text-gray-500 hover:text-orange-500"
                  >
                    {showConfirmPassword ? "Hide" : "Show"}
                  </button>
                </div>

                {confirmPassword && (
                  <p
                    className={`mt-1 text-xs ${
                      password === confirmPassword
                        ? "text-green-600"
                        : "text-red-500"
                    }`}
                  >
                    {password === confirmPassword
                      ? "Passwords match"
                      : "Passwords do not match"}
                  </p>
                )}
              </div>

              {/* Terms */}
              <div className="flex items-start gap-2 pt-1">
                <input
                  id="terms"
                  type="checkbox"
                  checked={agreeTerms}
                  onChange={(event) =>
                    setAgreeTerms(event.target.checked)
                  }
                  disabled={isLoading}
                  className="mt-1 h-4 w-4 shrink-0 accent-orange-500"
                />

                <label
                  htmlFor="terms"
                  className="text-xs leading-5 text-gray-600 sm:text-sm"
                >
                  I agree to the StudioSpace Terms and Conditions
                  and Privacy Policy.
                </label>
              </div>

              {message && (
                <div
                  role="status"
                  className="rounded-lg border border-orange-200 bg-orange-50 p-3 text-sm text-orange-800"
                >
                  {message}
                </div>
              )}

              {/* Register Button */}
              <button
                type="submit"
                disabled={isLoading}
                aria-busy={isLoading}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-orange-500 py-3.5 text-sm font-semibold text-white transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-70"
              >
                {isLoading ? (
                  <>
                    <span
                      aria-hidden="true"
                      className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white"
                    />
                    Validating...
                  </>
                ) : (
                  "Create Account"
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="my-5 flex items-center gap-3">
              <div className="h-px flex-1 bg-gray-200" />
              <span className="text-xs text-gray-400">
                Or continue with
              </span>
              <div className="h-px flex-1 bg-gray-200" />
            </div>

            {/* Google Sign In */}
            <button
              type="button"
              onClick={handleGoogleSignIn}
              className="flex w-full items-center justify-center gap-3 rounded-lg border border-gray-300 bg-white py-3 text-sm font-semibold text-gray-700 transition hover:bg-gray-50"
            >
              <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
                className="h-5 w-5"
              >
                <path
                  fill="#4285F4"
                  d="M21.35 12.22c0-.74-.07-1.45-.19-2.14H12v4.05h5.23a4.47 4.47 0 0 1-1.94 2.93v2.44h3.14c1.84-1.7 2.92-4.2 2.92-7.28Z"
                />
                <path
                  fill="#34A853"
                  d="M12 21.5c2.62 0 4.82-.87 6.43-2.36l-3.14-2.44c-.87.58-1.98.93-3.29.93-2.53 0-4.67-1.71-5.44-4.01H3.33v2.52A9.5 9.5 0 0 0 12 21.5Z"
                />
                <path
                  fill="#FBBC05"
                  d="M6.56 13.62a5.71 5.71 0 0 1 0-3.24V7.86H3.33a9.5 9.5 0 0 0 0 8.28l3.23-2.52Z"
                />
                <path
                  fill="#EA4335"
                  d="M12 6.37c1.42 0 2.69.49 3.69 1.46l2.77-2.77A9.08 9.08 0 0 0 12 2.5a9.5 9.5 0 0 0-8.67 5.36l3.23 2.52c.77-2.3 2.91-4.01 5.44-4.01Z"
                />
              </svg>
              Continue with Google
            </button>

            <p className="mt-6 text-center text-sm text-gray-500">
              Already have an account?{" "}
              <Link
                href="/login"
                className="font-bold text-orange-500 hover:underline"
              >
                Sign In
              </Link>
            </p>

            <div className="mt-6 border-t border-gray-100 pt-5 text-center">
              <p className="text-xs text-gray-400">
                © 2026 StudioSpace. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
