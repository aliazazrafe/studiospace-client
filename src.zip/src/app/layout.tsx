
import type { Metadata } from "next";
import "./globals.css";

import Navbar from "../components/layout/Navbar";
import Footer from "../components/Footer";
import ThemeProvider from "../components/ThemeProvider";
import Toaster from "../components/Toaster";

export const metadata: Metadata = {
  title: "StudioSpace",
  description: "Find and book creative studio spaces.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen bg-white text-slate-900 antialiased transition-colors duration-300 dark:bg-slate-950 dark:text-slate-100">
        <ThemeProvider>
          <Toaster />

          <div className="flex min-h-screen flex-col">
            <Navbar />

            <main className="flex-1 bg-[#f8fafc] transition-colors duration-300 dark:bg-slate-950">
              {children}
            </main>

            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}
